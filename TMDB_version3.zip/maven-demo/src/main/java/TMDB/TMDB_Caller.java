package TMDB;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.function.Supplier;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TMDB_Caller {

	//variables
	private String apiKey;

	
	//connstracteur---------------------------------------------------------------------------------------------------
	public TMDB_Caller(String apiKey) {
		super();
		this.apiKey = apiKey;
	}

	//listAllGenres_uri-------------------------------------------------------------------------------------------------
	public String listAllGenres_uri() {
		return "https://api.themoviedb.org/3/genre/movie/list?api_key="+apiKey+"&language=en-US";
	}
	
	
	//searchByGenre_uri-------------------------------------------------------------------------------------------------
	public String searchByGenre_uri(int genre_id) {
		return "https://api.themoviedb.org/3/discover/movie?api_key="+apiKey+"&language=en-US&sort_by=popularity.desc&page=1&include_adult=false&include_video=false&with_genres="+genre_id;
	}
	
	
	//searchByTitle_uri--------------------------------------------------------------------------------------------------
	public String searchByTitle_uri(String title_to_search) {
		return "https://api.themoviedb.org/3/search/movie?api_key="+apiKey+"&language=en-US&query="+title_to_search;
	}
	
	//searchByYear_uri--------------------------------------------------------------------------------------------------
	public String searchByYear_uri(String year) {
		//https://api.themoviedb.org/3/discover/movie?api_key=3aacfef6a62a872d2a4717b9b6cd5283&language=en-US&sort_by=popularity.asc&page=1&year=2020
		return "https://api.themoviedb.org/3/search/movie?api_key="+apiKey+"&language=en-US&sort_by=popularity.asc&page=1&query="+year;
	}
	
	//getAllGenres()----------------------------------------------------------------------------------------------------
	public List<Genre> getAllGenres() throws IOException, InterruptedException {
		String uri = listAllGenres_uri();
		
		HttpClient client = HttpClient.newHttpClient();
	    HttpRequest request = HttpRequest.newBuilder()
	          .uri(URI.create(uri))
	          .build();
	    
	    HttpResponse<Supplier<AllGenresBody>> response = client.send(request, new JsonBodyHandler<>(AllGenresBody.class));
	    Supplier<AllGenresBody> allGenres_result = response.body();
	    
	    String genres_str = allGenres_result.get().genres.toPrettyString();
	    
	    ObjectMapper mapper = new ObjectMapper();
	    List<Genre> genreList = mapper.readValue(genres_str, new TypeReference<List<Genre>>() {});
	    
	    return genreList;
	}
	
	//getMovieByGenre()----------------------------------------------------------------------------------------------------
		public List<Movie> getMoviesByGenre(int genre_id) throws IOException, InterruptedException {
			String uri = searchByGenre_uri(genre_id);
			//uri = "https://api.themoviedb.org/3/discover/movie?api_key=3aacfef6a62a872d2a4717b9b6cd5283&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&with_genre=14&page=1";
			System.out.println(uri);
			
			HttpClient client = HttpClient.newHttpClient();
		    HttpRequest request = HttpRequest.newBuilder()
		          .uri(URI.create(uri))
		          .build();
		    
		    HttpResponse<Supplier<TMDBResult>> response = client.send(request, new JsonBodyHandler<>(TMDBResult.class));
		    Supplier<TMDBResult> TMDB_result = response.body();
		    
		    String results_str = TMDB_result.get().results.toPrettyString();
		    
		    ObjectMapper mapper = new ObjectMapper();
		    List<Movie> movieList = mapper.readValue(results_str, new TypeReference<List<Movie>>() {});
		    
		    return movieList;
		}
	
	//getMoviesByTitle()----------------------------------------------------------------------------------------------------
	public List<Movie> getMoviesByTitle(String title) throws IOException, InterruptedException {
		String uri = searchByTitle_uri(title);
		//uri = "https://api.themoviedb.org/3/discover/movie?api_key=3aacfef6a62a872d2a4717b9b6cd5283&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&with_genre=14&page=1";
		System.out.println(uri);
		
		HttpClient client = HttpClient.newHttpClient();
	    HttpRequest request = HttpRequest.newBuilder()
	          .uri(URI.create(uri))
	          .build();
	    
	    HttpResponse<Supplier<TMDBResult>> response = client.send(request, new JsonBodyHandler<>(TMDBResult.class));
	    Supplier<TMDBResult> TMDB_result = response.body();
	    
	    String results_str = TMDB_result.get().results.toPrettyString();
	    
	    ObjectMapper mapper = new ObjectMapper();
	    List<Movie> movieList = mapper.readValue(results_str, new TypeReference<List<Movie>>() {});
	    
	    return movieList;
	}
	
	//getMoviesByYear()----------------------------------------------------------------------------------------------------
	public List<Movie> getMoviesByYear(String year) throws IOException, InterruptedException {
		String uri = searchByYear_uri(year);
		System.out.println(uri);
		
		HttpClient client = HttpClient.newHttpClient();
	    HttpRequest request = HttpRequest.newBuilder()
	          .uri(URI.create(uri))
	          .build();
	    
	    HttpResponse<Supplier<TMDBResult>> response = client.send(request, new JsonBodyHandler<>(TMDBResult.class));
	    Supplier<TMDBResult> TMDB_result = response.body();
	    
	    String results_str = TMDB_result.get().results.toPrettyString();
	    ObjectMapper mapper = new ObjectMapper();
	    List<Movie> movieList = mapper.readValue(results_str, new TypeReference<List<Movie>>() {});

	    return movieList;
	    
	}
	
	//getMovieByPeople()-----------------------------------------------------------------------------------------------------
	/*
	 * 
	 * 
	 * */
	
}//finClass

	