package TMDB;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Movie {
	
    public final String title;
    public final String release_date;
    
    //constracteur----------------------------------------------------------------------------------------
    public Movie(@JsonProperty("title") String title, @JsonProperty("release_date") String release_date) {
        this.title = title;
        this.release_date = release_date;
    }
    
}//finClass