package TMDB;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
//import com.fasterxml.jackson.core.type.TypeReference;


public class Rest_Caller {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		//variables
		String apiKey = "3aacfef6a62a872d2a4717b9b6cd5283";
		String title_to_search;
		int genre_id;
		String year;
	
		//create object 
		TMDB_Caller tmdb_caller = new TMDB_Caller(apiKey);
		
		
		//display all genres--------------------------------------------------------------------------------------------------
		System.out.println("List of All Genres : \n");
		List<Genre> genreList = tmdb_caller.getAllGenres();
		Genre genre;
	    for (int i=0; i<genreList.size(); i++) {
	    	genre = genreList.get(i);
	    	System.out.println("Genre " + (i+1) + " : " + genre.name);
	    }	
		
		//search by genre----------------------------------------------------------------------------------------------------
		
		System.out.println("Select your desired Genre to search: \n");
		Scanner sc1 = new Scanner(System.in);
		genre_id = genreList.get(sc1.nextInt()-1).id;
		
		List<Movie> movieList1 = tmdb_caller.getMoviesByGenre(genre_id);
		for (int i=0; i<10; i++)
	    	System.out.println("Movie " + (i+1) + ": " + movieList1.get(i).title);
	
	
	    //search by title----------------------------------------------------------------------------------------------------
		
		System.out.println("Title to search: \n");
		Scanner sc2 = new Scanner(System.in);
		title_to_search = sc2.next();	
		
		List<Movie> movieList2 = tmdb_caller.getMoviesByTitle(title_to_search);
		for (int i=0; i<movieList2.size(); i++)
	    	System.out.println("Movie " + (i+1) + ": " + movieList2.get(i).title + "(" + movieList2.get(i).release_date
	    			+ ")");
		
		
		//search by year-----------------------------------------------------------------------------------------------------
		
		System.out.println("Year: \n");
		Scanner sc3 = new Scanner(System.in);
		year = sc3.next();
		
		List<Movie> movieList3 = tmdb_caller.getMoviesByYear(year);
		
		for (int i=0; i<movieList3.size(); i++)
	    	System.out.println( movieList3.get(i).title + " --> "+ movieList3.get(i).release_date);
		
	   
		
	}//main
	
}//Rest_caller




